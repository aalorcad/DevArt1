package com.DEVARTV1.DEVARTV1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devartv1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
