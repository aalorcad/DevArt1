package com.DEVARTV1.DEVARTV1.service;
import com.DEVARTV1.DEVARTV1.model.Libro;
import com.DEVARTV1.DEVARTV1.repository.LibroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    public List<Libro> getLibros() {
        return libroRepository.obtenerLibros();
    }

    public Libro saveLibro(Libro libro) {
        if (libro.getTitulo() == null || libro.getTitulo().isEmpty()) {
            throw new IllegalArgumentException("El título del libro no puede estar vacío");
        }
        return libroRepository.guardar(libro);
    }

    public Libro getLibroId(int id) {
        return libroRepository.buscarPorId(id);
    }

    public Libro updateLibro(Libro libro) {
        libroRepository.buscarPorId(libro.getId());
        return libroRepository.actualizarLibro(libro);
    }

    public String deleteLibro(int id) {
        libroRepository.buscarPorId(id);
        libroRepository.eliminarLibro(id);
        return "Libro eliminado con éxito";
    }

    public Libro getFechaPublicacion(int fechaPublicacion) {
        return libroRepository.obtenerLibros().stream()
                .filter(libro -> libro.getFechaPublicacion() == fechaPublicacion)
                .findFirst()
                .orElse(null);
    }
    
    public Libro getLibroByIsbn(String isbn) {
        System.out.println("Buscando libro con ISBN: " + isbn);
        return libroRepository.getLibroByIsbn(isbn).orElse(null);


    }
}