package com.DEVARTV1.DEVARTV1.repository;
import com.DEVARTV1.DEVARTV1.model.Libro;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class LibroRepository {
    private List<Libro> listaLibros = new ArrayList<>();

    public List<Libro> obtenerLibros() {
        return listaLibros;
    }

    public Libro buscarPorId(int id) {
        for (Libro libro : listaLibros){
            if(libro.getId() == id){
                return libro;
            }
        }
            return null;
    }
    

    public Optional<Libro> getLibroByIsbn(String isbn) {
        return listaLibros.stream()
                .filter(libro -> libro.getIsbn().equals(isbn))
                .findFirst();
    }

    public Libro guardar(Libro libro) {
        if (listaLibros.stream().anyMatch(l -> l.getId() == libro.getId())) {
            throw new IllegalArgumentException("El libro con ID " + libro.getId() + " ya existe.");
        }
        listaLibros.add(libro);
        return libro;
    }

    public Libro actualizarLibro(Libro libro) {
        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getId() == libro.getId()) {
                listaLibros.set(i, libro);
                return libro;
            }
        }
        throw new IllegalArgumentException("El libro con ID " + libro.getId() + " no existe.");
    }

    public void eliminarLibro(int id) {
        Optional<Libro> libro = listaLibros.stream()
                .filter(l -> l.getId() == id)
                .findFirst();
        if (libro.isPresent()) {
            listaLibros.remove(libro.get());
        } else {
            throw new IllegalArgumentException("El libro con ID " + id + " no existe.");
        }
    }
}